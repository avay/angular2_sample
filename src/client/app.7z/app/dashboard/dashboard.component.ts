import { Component} from '@angular/core';
import { OnInit } from '@angular/core';
import { MerchantService } from '../shared/merchant-service/merchant-service.service';
import { Merchant} from '../shared/model/merchant';

/**
*	This class represents the lazy loaded DashboardComponent.
*/

@Component({
	moduleId: module.id,
	selector: 'dashboard-cmp',
	providers: [MerchantService],
	templateUrl: 'dashboard.component.html'
})

export class DashboardComponent implements OnInit {
   /*merchants: Merchant[];*/
   merchants: Array<Merchant>;
   errorMessage: string;
   constructor(private merchantService: MerchantService) {}

   getMerchants() {
		this.merchantService.getMerchants().subscribe(
				/*merchants => this.merchants = merchants,*/
				res => this.merchants = res,
				error =>  this.errorMessage = error
			);
		console.log('after executing the service');
   }
	ngOnInit():any {
		this.getMerchants();
		console.log('Merchants : ' + this.merchants);
   }
}
