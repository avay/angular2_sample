/**
 * This barrel file provides the export for the lazy loaded MerchantOnboardingComponent.
 */
export * from './merchant-onboarding.component';
export * from './merchant-onboarding.routes';

