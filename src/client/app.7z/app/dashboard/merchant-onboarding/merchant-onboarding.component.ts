import {Component} from '@angular/core';

@Component({
	moduleId: module.id,
	selector: 'merchant-onboarding',
	templateUrl: 'merchant-onboarding.component.html'
})

export class MerchantOnboardingComponent {
}

@Component({
	moduleId: module.id,
	selector: 'merchant-onboarding-sub-nav',
	templateUrl: 'merchant-onboarding-sub-nav.html'
})

export class MerchantOnboardingSubNavComponent { }
