/**
 * This barrel file provides the export for the lazy loaded BlankpageComponent.
 */
export * from './blankPage.component';
export * from './blankPage.routes';
