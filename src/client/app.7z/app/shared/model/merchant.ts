
export class Merchant {
  mid: string;
  dbaName: string;
  legalName: string;
  
  constructor(mid: string,
  			  dbaName: string,
  			  legalName: string) {
    this.mid = mid;
    this.legalName = legalName;
    this.dbaName = dbaName;
  }
}
