/**
 * This barrel file provides the export for the shared MerchantListService.
 */
export * from './merchant-service.service';
