import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Merchant} from '../model/merchant';

/**
 * This class provides the MerchantList service with methods to read merchants and add names.
 */


@Injectable()
export class MerchantService {

	merchants: Array<Merchant>;

  /**
   * Creates a new MerchantService with the injected Http.
   * @param {Http} http - The injected Http.
   * @constructor
   */
  constructor(private http: Http) {}

   getMerchants() {
   		console.log('response : ' + this.http.get('http://localhost:8888/merchants').map((response: Response) => <any>response.json()));
		return this.http.get('http://localhost:8888/merchants')
		.map((response: Response) => {return response.json();})
		.map((merchants: Array<any>) => {
			let result:Array<Merchant> = [];
			if (merchants) {
				merchants.forEach((merchant) => {
					result.push(new Merchant(merchant.mid, merchant.dbaName, merchant.legalName));
				});
			}
			return result;
		});
    }

  /**
    * Handle HTTP error
    */
  private handleError (error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
}

